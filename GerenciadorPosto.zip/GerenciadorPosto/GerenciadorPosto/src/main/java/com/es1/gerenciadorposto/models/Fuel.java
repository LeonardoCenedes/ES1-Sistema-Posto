/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.models;

/**
 * Represents a fuel that extends StaticFuel with additional fields for volume and total price.
 * Implements Serializable for saving and loading objects.
 * 
 * @author LeonardoCenedesPerei
 */
public class Fuel extends StaticFuel {
    private static final long serialVersionUID = 1L; 

    private double volume;
    private double totalPrice;

    public Fuel(String name, double price, double volume, double totalPrice) {
        super(name, price);
        this.volume = volume;
        this.totalPrice = totalPrice;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "Fuel{" + "name=" + getName() + ", price=" + getPrice() + ", volume=" + volume + ", totalPrice=" + totalPrice + '}';
    }
}
