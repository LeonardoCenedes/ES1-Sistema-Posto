/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import com.es1.gerenciadorposto.models.Fuel;
import com.es1.gerenciadorposto.models.StaticFuel;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class FuelController {
    public FuelController() {
    }

    public double calculatePrice(double price, double volume) {
        return price * volume;
    }

    public double calculateVolume(double price, double total) {
        return total / price;
    }

    public Fuel createFromStatic(StaticFuel staticFuel, double volume, double totalPrice) {
        Fuel fuel = new Fuel(staticFuel.getName(), staticFuel.getPrice(), volume, totalPrice);
        return fuel;
    }
}
