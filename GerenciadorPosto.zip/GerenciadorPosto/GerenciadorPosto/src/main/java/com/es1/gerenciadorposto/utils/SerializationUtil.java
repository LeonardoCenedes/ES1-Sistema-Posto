/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.utils;


import java.io.*;
import java.util.List;
/**
 *
 * @author LeonardoCenedesPerei
 */
public class SerializationUtil {

    /**
     * Saves a list of objects to a file.
     *
     * @param filePath The file path where the objects will be saved.
     * @param objects  The list of objects to save.
     * @param <T>      The type of objects in the list.
     * @throws IOException If an I/O error occurs.
     */
    public static <T> void saveToFile(String filePath, List<T> objects) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(objects);
        }
    }

    /**
     * Loads a list of objects from a file.
     *
     * @param filePath The file path from which the objects will be loaded.
     * @param <T>      The type of objects in the list.
     * @return The list of objects loaded from the file.
     * @throws IOException            If an I/O error occurs.
     * @throws ClassNotFoundException If the class of a serialized object cannot be found.
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> loadFromFile(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            return (List<T>) ois.readObject();
        }
    }
}