/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.models;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a purchase with lists of fuels and items, buyer CPF, date, and total price.
 * Implements Serializable for saving and loading objects.
 * 
 * @author LeonardoCenedes
 */
public class Buy implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Fuel> fuels;
    private List<Item> items; 
    private String buyerCPF;
    private LocalDateTime date;
    private double totalPrice;
    

    public Buy() {
        this.fuels = new ArrayList<>();
        this.items = new ArrayList<>();
        this.buyerCPF = "";
        this.date = LocalDateTime.now();
        this.totalPrice = 0.0;
    }

    public List<Fuel> getFuels() {
        return fuels;
    }

    public void setFuels(List<Fuel> fuels) {
        this.fuels = fuels;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public String getBuyerCPF() {
        return buyerCPF;
    }

    public void setBuyerCPF(String buyerCPF) {
        this.buyerCPF = buyerCPF;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void addFuel(Fuel fuel) {
        this.fuels.add(fuel);
        this.totalPrice += fuel.getPrice();
    }

    public void addItem(Item item) {
        this.items.add(item);
        this.totalPrice += item.getTotalPrice();
    }

    public void removeFuel(Fuel fuel) {
        this.fuels.remove(fuel);
        this.totalPrice -= fuel.getPrice();
    }

    public void removeItem(Item item) {
        this.items.remove(item);
        this.totalPrice -= item.getTotalPrice();
    }
    public List<Object> getItemsAndFuels() {
        List<Object> combinedList = new ArrayList<>();
        combinedList.addAll(fuels);
        combinedList.addAll(items);
        return combinedList;
    }

    @Override
    public String toString() {
        return "Buy{" + "fuels=" + fuels + ", items=" + items + ", buyerCPF=" + buyerCPF + ", date=" + date + ", totalPrice=" + totalPrice + '}';
    }
}
