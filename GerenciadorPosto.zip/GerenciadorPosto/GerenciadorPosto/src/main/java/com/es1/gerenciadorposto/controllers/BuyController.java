/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.es1.gerenciadorposto.models.Buy;
import com.es1.gerenciadorposto.models.Item;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.models.User;
import com.es1.gerenciadorposto.utils.SerializationUtil;

/**
 * Controller for managing purchases (Buy).
 * Handles loading and saving purchases to a file.
 * 
 * @author LeonardoCenedes
 */
public class BuyController {
    private final List<Buy> buys;
    private Buy openBuy;
    private final FuelController fuelController;
    private final UserController userController;
    private final ItemController itemController;
    private final String filePath = "buys.dat";

    public BuyController(FuelController fuelController, UserController userController, ItemController itemController) {
        this.buys = loadBuys();
        this.fuelController = fuelController;
        this.userController = userController;
        this.itemController = itemController;
    }

    private List<Buy> loadBuys() {
        try {
            return SerializationUtil.loadFromFile(filePath);
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    public void saveBuys() {
        try {
            SerializationUtil.saveToFile(filePath, buys);
        } catch (IOException e) {
            System.err.println("Error saving buys: " + e.getMessage());
        }
    }

    public void createNewBuy() {
        openBuy = new Buy();
    }

    public Buy getOpenBuy() {
        return openBuy;
    }

    public boolean verifyOpenBuy() {
        return openBuy == null;
    }

    public boolean addItem(StaticItem staticItem, int quantity) {
        try {
            Item item = itemController.createFromStatic(staticItem, quantity);
            openBuy.addItem(item);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean addFuel(StaticFuel fuel, Double fullPrice, Double volume) {
        try {
            if (fullPrice != null && volume == null) {
                volume = fuelController.calculateVolume(fuel.getPrice(), fullPrice);
            } else if (volume != null && fullPrice == null) {
                fullPrice = fuelController.calculatePrice(fuel.getPrice(), volume);
            } else if (fullPrice == null && volume == null) {
                throw new IllegalArgumentException("Either fullPrice or volume must be provided.");
            }
            openBuy.addFuel(fuelController.createFromStatic(fuel, volume, fullPrice));
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    public List<Buy> searchHistory(User user) {
        if (userController.roleVerification(user)) {
            return buys;
        }
        return List.of();
    }

    public boolean addBuy(Buy buy) {
        try {
            buys.add(buy);
            saveBuys();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean cancelBuy() {
        try {
            openBuy = null;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<Buy> applyFilters(LocalDateTime date, double value) {
        if (date != null && value != 0) {
            return buys.stream()
                    .filter(buy -> buy.getDate().isEqual(date) && buy.getTotalPrice() == value)
                    .collect(Collectors.toList());
        } else if (date != null) {
            return buys.stream()
                    .filter(buy -> buy.getDate().isEqual(date))
                    .collect(Collectors.toList());
        } else if (value != 0) {
            return buys.stream()
                    .filter(buy -> buy.getTotalPrice() == value)
                    .collect(Collectors.toList());
        }
        return List.of();
    }

    public boolean finishBuy(String cpf) {
        try {
            if (openBuy == null) {
                return false; 
            }
            if (cpf != null && !cpf.isEmpty()) {
                openBuy.setBuyerCPF(cpf);
            }
            if (!addBuy(openBuy)) {
                return false; 
            }
            openBuy = null;
            return true; 
        } catch (Exception e) {
            return false;
        }
    }
}
