/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.models;

/**
 * Represents an item that extends StaticItem with additional fields for quantity and total price.
 * Implements Serializable for saving and loading objects.
 * 
 * @author LeonardoCenedesPerei
 */
public class Item extends StaticItem {
    private static final long serialVersionUID = 1L; // Serialization ID

    private int quantity;
    private double totalPrice;

    public Item(int itemCode, String name, double price, int quantity) {
        super(itemCode, name, price);
        this.quantity = quantity;
        this.totalPrice = price * quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.totalPrice = getPrice() * quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "Item{" + "itemCode=" + getItemCode() + ", name=" + getName() + ", price=" + getPrice() + ", quantity=" + quantity + ", totalPrice=" + totalPrice + '}';
    }
}
