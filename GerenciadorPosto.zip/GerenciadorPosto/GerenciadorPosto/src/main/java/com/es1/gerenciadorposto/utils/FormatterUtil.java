/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.utils;

import java.text.DecimalFormat;

import com.es1.gerenciadorposto.models.Fuel;
import com.es1.gerenciadorposto.models.Item;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class FormatterUtil {

    private static final DecimalFormat currencyFormat = new DecimalFormat("R$ #,##0.00");
    private static final DecimalFormat volumeFormat = new DecimalFormat("#,##0.000L");
    private static final DecimalFormat priceFormat = new DecimalFormat("#,##0.00/L");

    public static String formatFuel(Fuel fuel) {
        return String.format("%s | %s | %s | %s",
                fuel.getName(),
                volumeFormat.format(fuel.getVolume()),
                priceFormat.format(fuel.getPrice()),
                currencyFormat.format(fuel.getTotalPrice()));
    }

    public static String formatItem(Item item) {
        return String.format("%04d | %s | %s | %d | %s",
                item.getItemCode(),
                item.getName(),
                currencyFormat.format(item.getPrice()),
                item.getQuantity(),
                currencyFormat.format(item.getTotalPrice()));
    }

    public static String formatStaticFuel(StaticFuel staticFuel) {
        return String.format("%s %.2f/L", staticFuel.getName(), staticFuel.getPrice());
    }

    public static String formatStaticItem(StaticItem staticItem) {
        return String.format("%04d | %s | %s",
                staticItem.getItemCode(),
                staticItem.getName(),
                formatCurrency(staticItem.getPrice()));
    }

    public static String formatCurrency(double value) {
        return String.format("R$ %.2f", value);
    }

    public static String formatVolume(double volume) {
        return String.format("%.4f", volume);
    }

    public static String formatCPF(String cpf) {
        // Remove any non-numeric characters
        cpf = cpf.replaceAll("\\D", "");

        // Format CPF to XXX.XXX.XXX-XX
        if (cpf.length() == 11) {
            return cpf.replaceFirst("(\\d{3})(\\d{3})(\\d{3})(\\d{2})", "$1.$2.$3-$4");
        }

        // Return the original CPF if it cannot be formatted
        return cpf;
    }

    public static String formatCPFRealTime(String cpf) {
        // Remove any non-numeric characters
        cpf = cpf.replaceAll("\\D", "");

        // Format CPF to XXX.XXX.XXX-XX dynamically
        if (cpf.length() <= 3) {
            return cpf;
        } else if (cpf.length() <= 6) {
            return cpf.replaceFirst("(\\d{3})(\\d+)", "$1.$2");
        } else if (cpf.length() <= 9) {
            return cpf.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "$1.$2.$3");
        } else if (cpf.length() <= 11) {
            return cpf.replaceFirst("(\\d{3})(\\d{3})(\\d{3})(\\d+)", "$1.$2.$3-$4");
        }

        // Truncate CPF if it exceeds 11 digits
        return cpf.substring(0, 11).replaceFirst("(\\d{3})(\\d{3})(\\d{3})(\\d+)", "$1.$2.$3-$4");
    }
}
