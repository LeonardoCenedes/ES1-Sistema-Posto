/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import com.es1.gerenciadorposto.models.Item;
import com.es1.gerenciadorposto.models.StaticItem;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class ItemController {
    public ItemController() {
    }
    
    public double calculatePrice(double price, int quantity) {
        return price * quantity;
    }

    public Item createFromStatic(StaticItem staticItem, int quantity) {
        Item item = new Item(staticItem.getItemCode(), staticItem.getName(), staticItem.getPrice(), quantity);
        return item;
    }
}
