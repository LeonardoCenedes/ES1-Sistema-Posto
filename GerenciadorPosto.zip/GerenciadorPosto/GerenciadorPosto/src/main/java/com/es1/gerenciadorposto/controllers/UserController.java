/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.es1.gerenciadorposto.enums.Roles;
import com.es1.gerenciadorposto.models.User;
import com.es1.gerenciadorposto.utils.SerializationUtil;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class UserController {
    private final List<User> users;
    private final String filePath = "users.dat";

    public UserController() {
        this.users = loadUsers();
    }

    private List<User> loadUsers() {
        try {
            return SerializationUtil.loadFromFile(filePath);
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    public void saveUsers() {
        try {
            SerializationUtil.saveToFile(filePath, users);
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    public boolean addUser(User user) {
        for (User existingUser : users) {
            if (existingUser.getUsername().equals(user.getUsername())) {
                return false;
            }
        }
        users.add(user);
        saveUsers();
        return true;
    }

    public boolean sendUserData(String username, String password, String fullname, Roles role, Date birthDate, String cpfString) {
        if (!validateUserData(username, password, fullname, role, birthDate, cpfString)) {
            return false;
        }
        User user = new User(fullname, username, password, role, birthDate, cpfString);
        return addUser(user);
    }

    public boolean validateUserData(String username, String password, String fullname, Roles role, Date birthDate, String cpfString) {
        if (!validateUsername(username)) {
            return false;
        }
        if (!validatePassword(password)) {
            return false;
        }
        if (!validateFullname(fullname)) {
            return false;
        }
        if (!validateRole(role)) {
            return false;
        }
        if (!validateBirthDate(birthDate)) {
            return false;
        }
        return validateCPF(cpfString);
    }

    public boolean validateUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return false;
            }
        }
        return true;
    }

    public boolean validatePassword(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*\\W).{9,}$");
    }

    public boolean validateFullname(String fullname) {
        return fullname.matches("^[A-Z][a-z]+( [A-Z][a-z]+)*$");
    }

    public boolean validateRole(Roles role) {
        return role != null;
    }

    public boolean validateBirthDate(Date birthDate) {
        LocalDate currentDate = LocalDate.now();
        LocalDate birthLocalDate = new java.sql.Date(birthDate.getTime()).toLocalDate();
        return Period.between(birthLocalDate, currentDate).getYears() >= 18;
    }

    public boolean validateCPF(String cpf) {
        cpf = cpf.replaceAll("\\D", "");
        if (cpf.length() != 11 || cpf.matches("(\\d)\\1{10}")) {
            return false;
        }
        try {
            int sum = 0;
            for (int i = 0; i < 9; i++) {
                sum += Character.getNumericValue(cpf.charAt(i)) * (10 - i);
            }
            int firstDigit = 11 - (sum % 11);
            if (firstDigit >= 10) {
                firstDigit = 0;
            }
            sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += Character.getNumericValue(cpf.charAt(i)) * (11 - i);
            }
            int secondDigit = 11 - (sum % 11);
            if (secondDigit >= 10) {
                secondDigit = 0;
            }
            return firstDigit == Character.getNumericValue(cpf.charAt(9)) &&
                secondDigit == Character.getNumericValue(cpf.charAt(10));
        } catch (Exception e) {
            return false;
        }
    }

    public boolean roleVerification(User user) {
        return user.getRole() == Roles.GERENTE;
    }

    public User sendLogin(String username, String password) {
        if(validateLoginData(username, password)){
            for (User user : users) {
                if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                    return user; 
                }
            }
        }
        return null;
    }

    public boolean validateLoginData(String username, String password) {
        return validatePassword(password);
    }

    public List<User> getUsers() {
        return users;
    }
}
