/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.models;

import java.io.Serializable;

/**
 * Represents a static fuel with a name and price.
 * Implements Serializable for saving and loading objects.
 * 
 * @author LeonardoCenedesPerei
 */
public class StaticFuel implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private double price;

    public StaticFuel(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "StaticFuel{" + "name='" + name + '\'' + ", price=" + price + '}';
    }
}
