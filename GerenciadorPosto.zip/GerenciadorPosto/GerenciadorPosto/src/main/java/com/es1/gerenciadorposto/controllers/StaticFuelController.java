/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.utils.SerializationUtil;

/**
 * Controller for managing static fuels.
 * Handles loading and saving static fuels to a file.
 * 
 * @author LeonardoCenedesPerei
 */
public class StaticFuelController {
    private final List<StaticFuel> staticFuels;
    private final String filePath = "staticFuels.dat";

    public StaticFuelController() {
        this.staticFuels = loadStaticFuels();
    }

    private List<StaticFuel> loadStaticFuels() {
        try {
            return SerializationUtil.loadFromFile(filePath);
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    public void saveStaticFuels() {
        try {
            SerializationUtil.saveToFile(filePath, staticFuels);
        } catch (IOException e) {
            System.err.println("Error saving static fuels: " + e.getMessage());
        }
    }

    public boolean addStaticFuel(StaticFuel staticFuel) {
        staticFuels.add(staticFuel);
        saveStaticFuels();
        return true;
    }

    public List<StaticFuel> searchFuelInfo() {
        return staticFuels;
    }

    public boolean validateNewValue(double newValue){
        if (newValue <= 0) {
            System.out.println("Invalid value. The value must be greater than zero.");
            return false;
        }
        return true;
    }

    public boolean updateFuelValue(StaticFuel staticFuel, double newValue) {
        if (validateNewValue(newValue)) {
            staticFuel.setPrice(newValue);
            saveStaticFuels();
            return true;
        }
        return false;
    }
}
