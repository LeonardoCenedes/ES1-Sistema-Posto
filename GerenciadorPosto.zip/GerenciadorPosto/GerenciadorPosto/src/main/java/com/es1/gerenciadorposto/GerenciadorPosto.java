/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.es1.gerenciadorposto;

import com.es1.gerenciadorposto.controllers.BuyController;
import com.es1.gerenciadorposto.controllers.FuelController;
import com.es1.gerenciadorposto.controllers.ItemController;
import com.es1.gerenciadorposto.controllers.StaticFuelController;
import com.es1.gerenciadorposto.controllers.StaticItemController;
import com.es1.gerenciadorposto.controllers.UserController;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.views.login;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class GerenciadorPosto {

    public static void main(String[] args) {
        // Initialize controllers in the correct order
        UserController userController = new UserController();
        StaticItemController staticItemController = new StaticItemController();
        StaticFuelController staticFuelController = new StaticFuelController();
        ItemController itemController = new ItemController();
        FuelController fuelController = new FuelController();
        BuyController buyController = new BuyController(fuelController, userController, itemController);

        // Populate initial data for StaticFuelController
        if (staticFuelController.searchFuelInfo().isEmpty()) {
            staticFuelController.addStaticFuel(new StaticFuel("Gasolina", 6.3));
            staticFuelController.addStaticFuel(new StaticFuel("Gasolina Aditivada", 6.34));
            staticFuelController.addStaticFuel(new StaticFuel("Etanol", 4.13));
            staticFuelController.addStaticFuel(new StaticFuel("Diesel", 6.22));
        }

        // Populate initial data for StaticItemController
        if (staticItemController.searchItems().isEmpty()) {
            staticItemController.addStaticItem(new StaticItem(1, "Água Mineral", 2.50));
            staticItemController.addStaticItem(new StaticItem(2, "Refrigerante Lata", 4.50));
            staticItemController.addStaticItem(new StaticItem(3, "Refrigerante 2L", 8.00));
            staticItemController.addStaticItem(new StaticItem(4, "Cerveja Lata", 3.50));
            staticItemController.addStaticItem(new StaticItem(5, "Cerveja Long Neck", 5.00));
            staticItemController.addStaticItem(new StaticItem(6, "Chocolate", 4.00));
            staticItemController.addStaticItem(new StaticItem(7, "Chiclete", 1.50));
            staticItemController.addStaticItem(new StaticItem(8, "Biscoito Salgado", 3.00));
            staticItemController.addStaticItem(new StaticItem(9, "Biscoito Doce", 3.50));
            staticItemController.addStaticItem(new StaticItem(10, "Pão de Queijo", 2.50));
            staticItemController.addStaticItem(new StaticItem(11, "Café Expresso", 4.00));
            staticItemController.addStaticItem(new StaticItem(12, "Sanduíche Natural", 6.00));
            staticItemController.addStaticItem(new StaticItem(13, "Energético", 8.50));
            staticItemController.addStaticItem(new StaticItem(14, "Suco de Fruta", 5.00));
            staticItemController.addStaticItem(new StaticItem(15, "Batata Chips", 7.00));
        }

        // Pass controllers to the login screen
        java.awt.EventQueue.invokeLater(() -> {
            new login(userController, buyController, staticItemController, staticFuelController).setVisible(true);
        });

        // Save data on application shutdown
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            userController.saveUsers();
            staticItemController.saveStaticItems();
            staticFuelController.saveStaticFuels();
            buyController.saveBuys();
        }));
    }
}
