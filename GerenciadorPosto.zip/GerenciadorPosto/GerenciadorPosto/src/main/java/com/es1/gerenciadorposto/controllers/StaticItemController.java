/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.utils.SerializationUtil;

/**
 * Controller for managing static items.
 * Handles loading and saving static items to a file.
 * 
 * @author LeonardoCenedesPerei
 */
public class StaticItemController {
    private final List<StaticItem> staticItems;
    private final String filePath = "staticItems.dat";

    public StaticItemController() {
        this.staticItems = loadStaticItems();
    }

    private List<StaticItem> loadStaticItems() {
        try {
            return SerializationUtil.loadFromFile(filePath);
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    public void saveStaticItems() {
        try {
            SerializationUtil.saveToFile(filePath, staticItems);
        } catch (IOException e) {
            System.err.println("Error saving static items: " + e.getMessage());
        }
    }

    public boolean addStaticItem(StaticItem staticItem) {
        staticItems.add(staticItem);
        saveStaticItems();
        return true;
    }

    public List<StaticItem> searchItems() {
        return staticItems;
    }
}
