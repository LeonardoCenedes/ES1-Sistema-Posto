/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.util.List;

import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.storage.PersistenceManager;

/**
 * Controller for managing static items.
 * Extends BaseStaticController to eliminate code duplication.
 * 
 * @author LeonardoCenedesPerei
 */
public class StaticItemController extends BaseStaticController<StaticItem> {

    public StaticItemController(PersistenceManager persistenceManager) {
        super(persistenceManager);
    }

    @Override
    public List<StaticItem> getAllEntities() {
        return persistenceManager.getAllStaticItems();
    }

    @Override
    protected boolean addEntity(StaticItem entity) {
        return persistenceManager.addStaticItem(entity);
    }

    @Override
    protected boolean updateEntityPrice(StaticItem entity, double newPrice) {
        return persistenceManager.updateStaticItemPrice(entity, newPrice);
    }
}
