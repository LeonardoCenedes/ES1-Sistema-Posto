/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.List;

import com.es1.gerenciadorposto.enums.Roles;
import com.es1.gerenciadorposto.models.User;
import com.es1.gerenciadorposto.storage.PersistenceManager;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class UserController {
    private final PersistenceManager persistenceManager;

    public UserController(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
    }

    public void saveUsers() {
        persistenceManager.saveAllData();
    }

    public boolean addUser(User user) {
        return persistenceManager.addUser(user);
    }

    public boolean sendUserData(String username, String password, String fullname, Roles role, Date birthDate, String cpfString) {
        if (!validateUserData(username, password, fullname, role, birthDate, cpfString)) {
            return false;
        }
        User user = new User(fullname, username, password, role, birthDate, cpfString);
        return addUser(user);
    }

    public boolean validateUserData(String username, String password, String fullname, Roles role, Date birthDate, String cpfString) {
        if (!validateUsername(username)) {
            return false;
        }
        if (!validatePassword(password)) {
            return false;
        }
        if (!validateFullname(fullname)) {
            return false;
        }
        if (!validateRole(role)) {
            return false;
        }
        if (!validateBirthDate(birthDate)) {
            return false;
        }
        return validateCPF(cpfString);
    }

    public boolean validateUsername(String username) {
        return persistenceManager.findUserByUsername(username).isEmpty();
    }

    public boolean validatePassword(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*\\W).{9,}$");
    }

    public boolean validateFullname(String fullname) {
        // Aceita nomes com acentos da língua portuguesa, ç, e caracteres especiais brasileiros
        return fullname.matches("^[A-ZÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ][a-záàâãéèêíìîóòôõúùûç]+( [A-ZÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ][a-záàâãéèêíìîóòôõúùûç]+)*$");
    }

    public boolean validateRole(Roles role) {
        return role != null;
    }

    public boolean validateBirthDate(Date birthDate) {
        LocalDate currentDate = LocalDate.now();
        LocalDate birthLocalDate = new java.sql.Date(birthDate.getTime()).toLocalDate();
        return Period.between(birthLocalDate, currentDate).getYears() >= 18;
    }

    public boolean validateCPF(String cpf) {
        cpf = cpf.replaceAll("\\D", "");
        if (cpf.length() != 11 || cpf.matches("(\\d)\\1{10}")) {
            return false;
        }
        try {
            int sum = 0;
            for (int i = 0; i < 9; i++) {
                sum += Character.getNumericValue(cpf.charAt(i)) * (10 - i);
            }
            int firstDigit = 11 - (sum % 11);
            if (firstDigit >= 10) {
                firstDigit = 0;
            }
            sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += Character.getNumericValue(cpf.charAt(i)) * (11 - i);
            }
            int secondDigit = 11 - (sum % 11);
            if (secondDigit >= 10) {
                secondDigit = 0;
            }
            return firstDigit == Character.getNumericValue(cpf.charAt(9)) &&
                secondDigit == Character.getNumericValue(cpf.charAt(10));
        } catch (Exception e) {
            return false;
        }
    }

    public User sendLogin(String username, String password) {
        if(validateLoginData(username, password)){
            return persistenceManager.findUserByUsername(username)
                    .filter(user -> user.getPassword().equals(password))
                    .orElse(null);
        }
        return null;
    }

    public boolean validateLoginData(String username, String password) {
        return validatePassword(password);
    }

    public List<User> getUsers() {
        return persistenceManager.getAllUsers();
    }
}
