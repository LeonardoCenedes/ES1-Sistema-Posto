/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.controllers;

import java.util.List;

import com.es1.gerenciadorposto.enums.Roles;
import com.es1.gerenciadorposto.models.Buy;
import com.es1.gerenciadorposto.models.Fuel;
import com.es1.gerenciadorposto.models.Item;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.models.User;
import com.es1.gerenciadorposto.storage.PersistenceManager;

/**
 * Controller for managing purchases (Buy).
 * Handles loading and saving purchases to a file.
 * 
 * @author LeonardoCenedes
 */
public class BuyController {
    private final PersistenceManager persistenceManager;
    private Buy openBuy;

    public BuyController(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
    }

    public void saveBuys() {
        persistenceManager.saveAllData();
    }

    public void createNewBuy() {
        openBuy = new Buy();
    }

    public Buy getOpenBuy() {
        return openBuy;
    }

    public boolean verifyOpenBuy() {
        return openBuy == null;
    }

    public boolean addItem(StaticItem staticItem, int quantity) {
        try {
            Item item = new Item(staticItem, quantity);
            openBuy.addItem(item);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean addFuel(StaticFuel staticFuel, double volume) {
        try {
            Fuel fuel = new Fuel(staticFuel, volume);
            openBuy.addFuel(fuel);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<Buy> searchHistory(User user) {
        if (user.getRole() == Roles.GERENTE) {
            return persistenceManager.getAllBuys();
        }
        return List.of();
    }

    public boolean addBuy(Buy buy) {
        return persistenceManager.addBuy(buy);
    }

    public boolean cancelBuy() {
        try {
            openBuy = null;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean finishBuy(String cpf) {
        try {
            if (openBuy == null) {
                return false; 
            }
            if (cpf != null && !cpf.isEmpty()) {
                openBuy.setBuyerCPF(cpf);
            }
            if (!addBuy(openBuy)) {
                return false; 
            }
            openBuy = null;
            return true; 
        } catch (Exception e) {
            return false;
        }
    }
}
