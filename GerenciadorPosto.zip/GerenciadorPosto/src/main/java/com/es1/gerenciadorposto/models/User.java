/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.es1.gerenciadorposto.models;

import java.io.Serializable;
import java.util.Date;

import com.es1.gerenciadorposto.enums.Roles;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class User implements  Serializable{
    private static final long serialVersionUID = 1L;

    private String fullName;
    private String username;
    private String password;
    private Roles role;
    private Date birthDate;
    private String cpf;

    public User(String fullName, String username, String password, Roles role, Date birthDate, String cpf) {
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.birthDate = birthDate;
        this.role = role;
        this.cpf = cpf;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Roles getRole() {
        return role;
    }

    public void setRole(Roles role) {
        this.role = role;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    @Override
    public String toString() {
        return "User{" + "fullName=" + fullName + ", username=" + username + ", password=" + password + ", birthDate=" + birthDate + ", cpf=" + cpf + '}';
    }
}
