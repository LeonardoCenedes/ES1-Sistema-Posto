/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.es1.gerenciadorposto;

import com.es1.gerenciadorposto.controllers.UserController;
import com.es1.gerenciadorposto.storage.PersistenceManager;
import com.es1.gerenciadorposto.views.login;

/**
 *
 * @author LeonardoCenedesPerei
 */
public class GerenciadorPosto {

    public static void main(String[] args) {
        // Initialize the persistence manager and load all data
        PersistenceManager persistenceManager = PersistenceManager.getInstance();
        persistenceManager.loadAllData();
        
        // Initialize only the UserController for login
        UserController userController = new UserController(persistenceManager);

        // Launch the login screen
        java.awt.EventQueue.invokeLater(() -> {
            new login(userController).setVisible(true);
        });

        // Save data on application shutdown
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            persistenceManager.saveAllData();
        }));
    }
}
