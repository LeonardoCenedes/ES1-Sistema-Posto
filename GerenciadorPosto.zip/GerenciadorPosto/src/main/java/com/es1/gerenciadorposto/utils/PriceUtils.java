package com.es1.gerenciadorposto.utils;

import java.text.DecimalFormat;

import com.es1.gerenciadorposto.models.PriceableEntity;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;

/**
 * Utility class for price-related operations and formatting.
 * Centralizes all price logic to eliminate duplication.
 * 
 * @author LeonardoCenedesPerei
 */
public class PriceUtils {
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");
    
    /**
     * Formats a price value with Brazilian currency format
     */
    public static String formatPrice(double price) {
        return "R$ " + PRICE_FORMAT.format(price);
    }
    
    /**
     * Parses a price string, accepting both comma and dot as decimal separator
     */
    public static double parsePrice(String priceText) throws NumberFormatException {
        if (priceText == null || priceText.trim().isEmpty()) {
            throw new NumberFormatException("Price text cannot be empty");
        }
        
        // Remove currency symbols and normalize decimal separator
        String normalizedPrice = priceText.trim()
                .replace("R$", "")
                .replace(" ", "")
                .replace(",", ".");
        
        return Double.parseDouble(normalizedPrice);
    }
    
    /**
     * Validates if a price value is valid (positive)
     */
    public static boolean isValidPrice(double price) {
        return price > 0;
    }
    
    /**
     * Generic method to format any priceable entity
     */
    public static String formatPriceableEntity(PriceableEntity entity) {
        if (entity == null) {
            return "Entidade nula";
        }
        if (entity instanceof StaticFuel) {
            return String.format("%s %.2f/L", entity.getName(), entity.getPrice());
        } else if (entity instanceof StaticItem item) {
            return String.format("%04d | %s | %s", 
                    item.getItemCode(), 
                    item.getName(), 
                    formatPrice(item.getPrice()));
        }
        return entity.getName() + " - " + formatPrice(entity.getPrice());
    }
    
    /**
     * Safely updates price with validation
     */
    public static boolean updatePrice(PriceableEntity entity, double newPrice) {
        if (!isValidPrice(newPrice)) {
            return false;
        }
        entity.setPrice(newPrice);
        return true;
    }
}
