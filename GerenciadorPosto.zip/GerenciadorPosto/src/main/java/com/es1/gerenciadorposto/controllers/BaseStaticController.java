package com.es1.gerenciadorposto.controllers;

import java.util.List;

import com.es1.gerenciadorposto.storage.PersistenceManager;

/**
 * Controller base genérico para gerenciar entidades estáticas.
 * Elimina duplicação de código entre StaticItemController e StaticFuelController.
 * 
 * @param <T> Tipo da entidade estática (StaticItem ou StaticFuel)
 * @author LeonardoCenedesPerei
 */
public abstract class BaseStaticController<T> {
    protected final PersistenceManager persistenceManager;
    
    public BaseStaticController(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
    }
    
    public abstract List<T> getAllEntities();
    
    protected abstract boolean addEntity(T entity);
    
    protected abstract boolean updateEntityPrice(T entity, double newPrice);
    
    protected boolean validateNewValue(double newValue) {
        if (newValue <= 0) {
            System.out.println("Valor inválido: " + newValue + ". Deve ser maior que zero.");
            return false;
        }
        return true;
    }
    
    protected void saveData() {
        persistenceManager.saveAllData();
    }
    
    public boolean updateValue(T entity, double newValue) {
        if (validateNewValue(newValue)) {
            return updateEntityPrice(entity, newValue);
        }
        return false;
    }
}
