package com.es1.gerenciadorposto.models;

/**
 * Interface para entidades que possuem preço.
 * Permite tratamento uniforme de StaticItem e StaticFuel.
 * 
 * @author LeonardoCenedesPerei
 */
public interface PriceableEntity {
    double getPrice();
    void setPrice(double price);
    String getName();
}
