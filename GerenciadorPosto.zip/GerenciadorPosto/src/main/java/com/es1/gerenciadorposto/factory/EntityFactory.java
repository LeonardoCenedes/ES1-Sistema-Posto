package com.es1.gerenciadorposto.factory;

import com.es1.gerenciadorposto.models.Fuel;
import com.es1.gerenciadorposto.models.Item;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;

/**
 * Factory class for creating static entities and their runtime counterparts.
 * Centralizes object creation and ensures consistency.
 * 
 * @author LeonardoCenedesPerei
 */
public class EntityFactory {
    
    public static StaticFuel createStaticFuel(String name, double price) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do combustível não pode estar vazio");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("Preço do combustível deve ser positivo");
        }
        return new StaticFuel(name.trim(), price);
    }
    
    public static StaticItem createStaticItem(int itemCode, String name, double price) {
        if (itemCode <= 0) {
            throw new IllegalArgumentException("Código do produto deve ser positivo");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do produto não pode estar vazio");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("Preço do produto deve ser positivo");
        }
        return new StaticItem(itemCode, name.trim(), price);
    }

    public static Fuel createFuel(StaticFuel staticFuel, double volume) {
        if (staticFuel == null) {
            throw new IllegalArgumentException("Combustível estático não pode ser nulo");
        }
        if (volume <= 0) {
            throw new IllegalArgumentException("Volume deve ser positivo");
        }
        return new Fuel(staticFuel, volume);
    }
    
    public static Item createItem(StaticItem staticItem, int quantity) {
        if (staticItem == null) {
            throw new IllegalArgumentException("Produto estático não pode ser nulo");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantidade deve ser positiva");
        }
        return new Item(staticItem, quantity);
    }
}
