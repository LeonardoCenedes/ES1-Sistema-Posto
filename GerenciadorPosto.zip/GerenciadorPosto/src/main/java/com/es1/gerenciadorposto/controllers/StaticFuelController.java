package com.es1.gerenciadorposto.controllers;

import java.util.List;

import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.storage.PersistenceManager;

/**
 * Controller for managing static fuels.
 * Extends BaseStaticController to eliminate code duplication.
 * 
 * @author LeonardoCenedesPerei
 */
public class StaticFuelController extends BaseStaticController<StaticFuel> {

    public StaticFuelController(PersistenceManager persistenceManager) {
        super(persistenceManager);
    }

    @Override
    public List<StaticFuel> getAllEntities() {
        return persistenceManager.getAllStaticFuels();
    }

    @Override
    protected boolean addEntity(StaticFuel entity) {
        return persistenceManager.addStaticFuel(entity);
    }

    @Override
    protected boolean updateEntityPrice(StaticFuel entity, double newPrice) {
        return persistenceManager.updateStaticFuelPrice(entity, newPrice);
    }
}
