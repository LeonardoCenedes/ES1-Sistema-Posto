package com.es1.gerenciadorposto.storage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.es1.gerenciadorposto.models.Buy;
import com.es1.gerenciadorposto.models.StaticFuel;
import com.es1.gerenciadorposto.models.StaticItem;
import com.es1.gerenciadorposto.models.User;
import com.es1.gerenciadorposto.utils.SerializationUtil;

/**
 * Gerenciador de persistência de dados.
 * Responsável por carregar, salvar e fornecer acesso aos dados da aplicação.
 * 
 * @author leona
 */
public class PersistenceManager {
    
    private List<User> users;
    private List<StaticItem> staticItems;
    private List<StaticFuel> staticFuels;
    private List<Buy> buys;
    
    private boolean dataLoaded = false;
    private long lastSaveTime = 0;
    private static final long SAVE_COOLDOWN = 1000;

    private PersistenceManager() {
        this.users = new ArrayList<>();
        this.staticItems = new ArrayList<>();
        this.staticFuels = new ArrayList<>();
        this.buys = new ArrayList<>();
    }

    // Initialization-on-demand holder idiom for thread-safe singleton
    private static class Holder {
        private static final PersistenceManager INSTANCE = new PersistenceManager();
    }

    public static PersistenceManager getInstance() {
        return Holder.INSTANCE;
    }

    /**
     * Carrega todos os dados
     */
    public void loadAllData() {
        if (!dataLoaded) {
            loadUsers();
            loadStaticItems();
            loadStaticFuels();
            loadBuys();
            initializeDefaultData();
            dataLoaded = true;
        }
    }
    /**
     * Salvamento otimizado com cooldown
     */
    public synchronized void saveAllData() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastSaveTime < SAVE_COOLDOWN) {
            return; // Evita salvamentos muito frequentes
        }
        
        saveUsers();
        saveStaticItems();
        saveStaticFuels();
        saveBuys();
        lastSaveTime = currentTime;
    }
    
    /**
     * Busca usuário por username usando busca linear
     */
    public Optional<User> findUserByUsername(String username) {
        return users.stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst();
    }
    
    /**
     * Busca item por código usando busca linear
     */
    public Optional<StaticItem> findStaticItemByCode(int itemCode) {
        return staticItems.stream()
                .filter(item -> item.getItemCode() == itemCode)
                .findFirst();
    }
    
    /**
     * Busca combustível por nome usando busca linear
     */
    public Optional<StaticFuel> findStaticFuelByName(String name) {
        return staticFuels.stream()
                .filter(fuel -> fuel.getName().equals(name))
                .findFirst();
    }
    
    /**
     * Adiciona usuário
     */
    public boolean addUser(User user) {
        if (users.add(user)) {
            saveUsers();
            return true;
        }
        return false;
    }
    
    /**
     * Adiciona item estático
     */
    public boolean addStaticItem(StaticItem item) {
        if (staticItems.add(item)) {
            saveStaticItems();
            return true;
        }
        return false;
    }
    
    /**
     * Adiciona combustível estático
     */
    public boolean addStaticFuel(StaticFuel fuel) {
        if (staticFuels.add(fuel)) {
            saveStaticFuels();
            return true;
        }
        return false;
    }
    
    // Métodos de acesso otimizados (retornam cópias para segurança)
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
    
    public List<StaticItem> getAllStaticItems() {
        return new ArrayList<>(staticItems);
    }
    
    public List<StaticFuel> getAllStaticFuels() {
        return new ArrayList<>(staticFuels);
    }
    
    public List<Buy> getAllBuys() {
        return new ArrayList<>(buys);
    }
    
    // Métodos de carregamento (usando SerializationUtil diretamente)
    private void loadUsers() {
        try {
            this.users = SerializationUtil.loadFromFile("users.dat");
        } catch (IOException | ClassNotFoundException e) {
            this.users = new ArrayList<>();
        }
    }
    
    private void loadStaticItems() {
        try {
            this.staticItems = SerializationUtil.loadFromFile("staticItems.dat");
        } catch (IOException | ClassNotFoundException e) {
            this.staticItems = new ArrayList<>();
        }
    }
    
    private void loadStaticFuels() {
        try {
            this.staticFuels = SerializationUtil.loadFromFile("staticFuels.dat");
        } catch (IOException | ClassNotFoundException e) {
            this.staticFuels = new ArrayList<>();
        }
    }
    
    private void loadBuys() {
        try {
            this.buys = SerializationUtil.loadFromFile("buys.dat");
        } catch (IOException | ClassNotFoundException e) {
            this.buys = new ArrayList<>();
        }
    }
    
    // Métodos de salvamento (usando SerializationUtil diretamente)
    private void saveUsers() {
        try {
            SerializationUtil.saveToFile("users.dat", this.users);
        } catch (IOException e) {
            System.err.println("Erro ao salvar usuários: " + e.getMessage());
        }
    }
    
    private void saveStaticItems() {
        try {
            SerializationUtil.saveToFile("staticItems.dat", this.staticItems);
        } catch (IOException e) {
            System.err.println("Erro ao salvar itens: " + e.getMessage());
        }
    }
    
    private void saveStaticFuels() {
        try {
            SerializationUtil.saveToFile("staticFuels.dat", this.staticFuels);
        } catch (IOException e) {
            System.err.println("Erro ao salvar combustíveis: " + e.getMessage());
        }
    }
    
    private void saveBuys() {
        try {
            SerializationUtil.saveToFile("buys.dat", this.buys);
        } catch (IOException e) {
            System.err.println("Erro ao salvar compras: " + e.getMessage());
        }
    }
    
    /**
     * Inicializa dados padrão se necessário
     */
    private void initializeDefaultData() {
        initializeDefaultFuels();
        initializeDefaultItems();
    }
    
    private void initializeDefaultFuels() {
        if (staticFuels.isEmpty()) {
            staticFuels.add(new StaticFuel("Gasolina", 6.3));
            staticFuels.add(new StaticFuel("Gasolina Aditivada", 6.34));
            staticFuels.add(new StaticFuel("Etanol", 4.13));
            staticFuels.add(new StaticFuel("Diesel", 6.22));
            saveStaticFuels();
        }
    }
    
    private void initializeDefaultItems() {
        if (staticItems.isEmpty()) {
            staticItems.add(new StaticItem(1, "Água Mineral", 2.50));
            staticItems.add(new StaticItem(2, "Refrigerante Lata", 4.50));
            staticItems.add(new StaticItem(3, "Refrigerante 2L", 8.00));
            staticItems.add(new StaticItem(4, "Cerveja Lata", 3.50));
            staticItems.add(new StaticItem(5, "Cerveja Long Neck", 5.00));
            staticItems.add(new StaticItem(6, "Chocolate", 4.00));
            staticItems.add(new StaticItem(7, "Chiclete", 1.50));
            staticItems.add(new StaticItem(8, "Biscoito Salgado", 3.00));
            staticItems.add(new StaticItem(9, "Biscoito Doce", 3.50));
            staticItems.add(new StaticItem(10, "Pão de Queijo", 2.50));
            staticItems.add(new StaticItem(11, "Café Expresso", 4.00));
            staticItems.add(new StaticItem(12, "Sanduíche Natural", 6.00));
            staticItems.add(new StaticItem(13, "Energético", 8.50));
            staticItems.add(new StaticItem(14, "Suco de Fruta", 5.00));
            staticItems.add(new StaticItem(15, "Batata Chips", 7.00));
            saveStaticItems();
        }
    }
    
    // Métodos de atualização
    public boolean updateStaticFuelPrice(StaticFuel fuel, double newPrice) {
        fuel.setPrice(newPrice);
        saveStaticFuels();
        return true;
    }
    
    public boolean updateStaticItemPrice(StaticItem item, double newPrice) {
        item.setPrice(newPrice);
        saveStaticItems();
        return true;
    }
    
    // Métodos para compras
    public boolean addBuy(Buy buy) {
        if (buys.add(buy)) {
            saveBuys();
            return true;
        }
        return false;
    }
}
